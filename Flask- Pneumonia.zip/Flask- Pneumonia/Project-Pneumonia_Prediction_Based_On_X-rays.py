#!/usr/bin/env python
# coding: utf-8

# In[1]:


from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Convolution2D
from keras.layers import MaxPooling2D
from keras.layers import Flatten


# In[2]:


model=Sequential()


# In[3]:


model.add(Convolution2D(32,(3,3),input_shape=(128,128,3),activation="relu"))


# In[4]:


model.add(MaxPooling2D(pool_size = (2, 2)))


# In[5]:


model.add(Flatten())


# In[6]:


model.add(Dense(init="uniform",activation="relu",output_dim=120))


# In[7]:


model.add(Dense(init="uniform",activation="relu",output_dim=30))


# In[8]:


model.add(Dense(init="uniform",activation="sigmoid",output_dim=1))


# In[9]:


model.compile(loss="binary_crossentropy",optimizer="adam",metrics=["accuracy"])


# In[10]:


from keras.preprocessing.image import ImageDataGenerator


# In[11]:


train_datagen = ImageDataGenerator(rescale = 1./255,
                                   shear_range = 0.2,
                                   zoom_range = 0.2,
                                   horizontal_flip = True)


# In[12]:


test_datagen = ImageDataGenerator(rescale = 1./255)


# In[13]:


x_train = train_datagen.flow_from_directory(r'C:\Users\Md Hussain\Downloads\chest-xray-pneumonia\chest_xray\train',
                                                 target_size = (128, 128),
                                                 batch_size = 32,
                                                     class_mode = 'binary')


# In[14]:


x_test = test_datagen.flow_from_directory(r'C:\Users\Md Hussain\Downloads\chest-xray-pneumonia\chest_xray\test',
                                            target_size = (128, 128),
                                            batch_size = 32,
                                            class_mode = 'binary')


# In[15]:


print(x_train.class_indices)


# In[16]:


model.fit_generator(x_train,
                         steps_per_epoch = 300,
                         epochs = 10,
                         validation_data = x_test,
                         validation_steps = 63)


# In[17]:


model.save("Pneumonia.h5")


# In[18]:


from keras.models import load_model


# In[19]:


import cv2


# In[20]:


import numpy as np


# In[21]:


model2 = load_model("Pneumonia.h5")


# In[22]:


model2.compile(loss='categorical_crossentropy',
                      optimizer='adam',
                      metrics=['accuracy'])


# In[23]:


from skimage.transform import resize


# In[24]:


def detect(frame):
    try:
        img = resize(frame,(128,128))
        img = np.expand_dims(img,axis=0)
        if(np.max(img)>1):
            img = img/255.0
        prediction = model2.predict(img)
        print(prediction)
        prediction = model2.predict_classes(img)
        print(prediction)
    except AttributeError:
        print("shape not found")


# In[29]:


frame=cv2.imread(r"C:\Users\Md Hussain\Downloads\chest-xray-pneumonia\chest_xray\test\PNEUMONIA\person82_bacteria_403.jpeg")


# In[30]:


data = detect(frame)


# In[ ]:




