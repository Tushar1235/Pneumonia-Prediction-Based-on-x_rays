from __future__ import division, print_function
import sys
import os
import glob
import re
import cv2
import numpy as np
from keras.models import load_model
from keras.preprocessing import image
from flask import Flask, redirect, url_for, request, render_template
from werkzeug.utils import secure_filename
from gevent.pywsgi import WSGIServer
from skimage.transform import resize

app = Flask(__name__)

MODEL_PATH = 'Pneumonia.h5'





def model_predict(img_path, model):
    img = image.load_img(img_path, target_size=(128, 128))
    print("after")
    img = np.asarray(img)
    #frame=cv2.imread(img)
    print(type(img))
    try:
        img = resize(img,(128,128))
        img = np.expand_dims(img,axis=0)
        if(np.max(img)>1): 
            img = img/255.0
        
        prediction = model.predict(img)
        print(prediction)
        return prediction
    except AttributeError:
        return "shape not found"



@app.route('/', methods=['GET'])
def index():
    return render_template('base.html')


@app.route('/predict', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        f = request.files['image']

        basepath = os.path.dirname(__file__)
        file_path = os.path.join(basepath, 'uploads', secure_filename(f.filename))
        f.save(file_path)
        model = load_model('Pneumonia.h5')
        preds = model_predict(file_path, model)
        print("some"+str(preds))
        if preds<0.5:
            result = "It is a Normal X-Ray"
        elif preds>=0.5:
            result = "You are infected!!"
        else:
            result="Shape Not Found"
        return result
    return None


if __name__ == '__main__':

    http_server = WSGIServer(('0.0.0.0', 5000), app)
    http_server.serve_forever()
